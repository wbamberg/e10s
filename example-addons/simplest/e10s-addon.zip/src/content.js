addEventListener("click", function (event) {
  sendSyncMessage("click");
  window.alert("they clicked");
}, false);
